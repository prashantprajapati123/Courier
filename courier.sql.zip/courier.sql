-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 07, 2014 at 09:24 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `courier`
--

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(255) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`cid`, `cname`) VALUES
(1, 'Indore'),
(2, 'dewas'),
(3, 'bhopal'),
(4, 'Indore'),
(5, 'xdtgxdgxdghxh'),
(6, 'hggh'),
(7, 'ydyyr'),
(8, 'eaeaee'),
(9, 'dsfsf');

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE IF NOT EXISTS `complain` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`com_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `complain`
--

INSERT INTO `complain` (`com_id`, `title`, `description`, `name`, `contact`, `email`, `date`) VALUES
(1, 'late service', 'gyugujhv uv gucv u', 'Vini', 12, 'a@gmail.com', '28/09/14'),
(2, 'late service', 'gyugujhv uv gucv u', 'Vini', 12, 'r@gmil.com', '28/09/14');

-- --------------------------------------------------------

--
-- Table structure for table `courier`
--

CREATE TABLE IF NOT EXISTS `courier` (
  `c_id` varchar(255) NOT NULL,
  `from_name` varchar(255) NOT NULL,
  `to_name` varchar(255) NOT NULL,
  `from_contact` int(11) NOT NULL,
  `to_contact` int(11) NOT NULL,
  `from_address` varchar(255) NOT NULL,
  `to_address` varchar(255) NOT NULL,
  `from_city` varchar(255) NOT NULL,
  `to_city` varchar(255) NOT NULL,
  `post_date` varchar(255) NOT NULL,
  `subadmin` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `city_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courier`
--

INSERT INTO `courier` (`c_id`, `from_name`, `to_name`, `from_contact`, `to_contact`, `from_address`, `to_address`, `from_city`, `to_city`, `post_date`, `subadmin`, `status`, `city_status`) VALUES
('123', 'nikunj', 'rupendra', 789456, 346798798, 'sukhlia', 'palasia', 'jaipur', 'ajmer', '2014-09-29', 'bharat', 'Dispatch', 'pune'),
('5146', 'rahul', 'aarchi', 56456, 5646, 'aazad nagar', 'sadar bzar', 'raipur', 'khargone', '29/09/2014', 'bharat', 'Dispatch', 'pune'),
('dhdhdfh', 'dfhdfhhh', 'dfhdhdh', 43433, 0, 'hdhhhd', 'dfhdfhh', 'dhdhh', 'dfhdhdh', '2014-10-07', 'bharat', 'Pending', 'dfhdhdh');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `p_address` varchar(255) NOT NULL,
  `ofc_address` varchar(255) NOT NULL,
  `reg_date` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `contact` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `type`, `email`, `name`, `city`, `p_address`, `ofc_address`, `reg_date`, `status`, `contact`, `id`) VALUES
('aarchi', '5146', 'admin', '', '', '', '', '', '', '', 0, 1),
('bharat', '123', 'subadmin', 'b@gmail.com', 'bharat', 'Indore', 'sudama nagar', 'New palasia', '29/09/2014', 'pending', 456123, 5);
